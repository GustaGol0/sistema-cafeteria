int vender(float x);

int menuPrincipal();

int menuAlteracao();

void lidarMenuPrincipal(unsigned int opcao);

void cadastrarItemCardapio();

void consultarItemCardapio();

void mostrarItemCardapio();

void vendas();