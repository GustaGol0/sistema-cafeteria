#define TAMANHO_NOME 100

#define DIVISOR "------------------------------"

#define COR_VERMELHO "\033[0;31m"

#define COR_VERDE "\033[0;32m"

#define COR_DEFAULT "\033[0m"

#define ARQUIVO_CARDAPIO "cardapio.txt"