#ifndef _TIPOS
#define _TIPOS
#include "variaveis.h"

typedef struct {
  char nome[TAMANHO_NOME];
  float preco;
  unsigned int estoque;
} ItemCardapio;

#endif